#Data of User who register in this sys
Account = {"Supasin": {"telephone":"0987654321",
                       "gmail":"supasin@gmail.com",
                       "password":"1234"},
           "Acharayut": {"telephone":"0123456789",
                       "gmail":"Acharayut@gmail.com",
                       "password":"1234"} 
            }